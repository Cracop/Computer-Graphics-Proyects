#version 330

out vec4 outputColor;

void main()
{
    outputColor = vec4(0.87, 0.734, 0.082, 1.0);
}