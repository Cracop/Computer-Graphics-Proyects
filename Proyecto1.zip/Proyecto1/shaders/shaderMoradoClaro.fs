#version 330

out vec4 outputColor;

void main()
{
    outputColor = vec4(0.6, 0.196, 0.8, 1.0);
}